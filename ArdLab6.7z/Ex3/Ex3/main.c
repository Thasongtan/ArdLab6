#include <avr/io.h>
void fInitTimer() {
	DDRD |= _BV(PD6); // Set PD6 as OC0A output
	TCCR0A |= (1<<WGM01)|(1<<WGM00); // Set Fast mode for Timer0
	TCCR0A |= (1<<COM0A1); // Non-inverting mode for OC0A
	TCCR0B |= (1<<CS01)|(1<<CS00); // Timer0 Clock=ClockIO/64
	OCR0A = 20; // Set default On-time
}
void fInitADC() {
	ADMUX |= (1<<REFS0)|(1<<ADLAR); // Vref=AVcc=5V,8-bit,ch0
	DIDR0 |= (1<<PINC0); // PC0 disabled
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); // CLKadc=CLKsys/128
	ADCSRA |= (1<<ADEN); // ADC Enabled
}
int main(void) {
	fInitTimer(); // Configure Timer0
	fInitADC(); // Configure ADC
	while(1) {
		ADCSRA |= (1<<ADSC); // Start conversion
		while (ADCSRA&(1<<ADSC)); // Wait until conversion done
		OCR0A = ADCH; // Read 8-bit ADC output
	}
}